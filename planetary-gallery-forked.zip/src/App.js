
import "./styles.css";

import Cards from "./Components/Cards";

export default function App() {
  

  return (
    <div className="App">
    <div>
        <h1> Planetary Gallery </h1>
     </div>
      <Cards />
    </div>
  );
}
